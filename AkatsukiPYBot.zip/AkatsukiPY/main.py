import os
import re

# Define patterns for sensitive information
TOKEN_PATTERN = r'(?i)(bot(?:_token)?[\s:=]*["\']?([a-z0-9]{32})["\']?)'  # Match bot tokens (32 chars)
ADMIN_ID_PATTERN = r'(?i)(admin[\s:=]*["\']?(\d+)["\']?)'  # Match admin IDs
API_URL_PATTERN = r'https?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'  # Match URLs

def search_for_details_in_file(file_path):
    """
    Search for Bot Token, Admin ID, and API URL in a given file.
    """
    sensitive_info = {
        "Bot Token": [],
        "Admin ID": [],
        "API URL": []
    }

    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
            content = file.read()

            # Search for Bot Token
            bot_tokens = re.findall(TOKEN_PATTERN, content)
            if bot_tokens:
                sensitive_info["Bot Token"].append((file_path, bot_tokens))

            # Search for Admin ID
            admin_ids = re.findall(ADMIN_ID_PATTERN, content)
            if admin_ids:
                sensitive_info["Admin ID"].append((file_path, admin_ids))

            # Search for API URL
            api_urls = re.findall(API_URL_PATTERN, content)
            if api_urls:
                sensitive_info["API URL"].append((file_path, api_urls))

    except Exception as e:
        print(f"Could not read file {file_path}: {e}")

    return sensitive_info


def search_directory_for_bot_details(directory_path):
    """
    Walk through all files in the directory and search for Bot Token, Admin ID, API URL.
    """
    sensitive_info = {
        "Bot Token": [],
        "Admin ID": [],
        "API URL": []
    }

    if not os.path.exists(directory_path):
        print(f"The provided path '{directory_path}' does not exist!")
        return None

    # Walk through all files in the provided directory
    for foldername, subfolders, filenames in os.walk(directory_path):
        for filename in filenames:
            file_path = os.path.join(foldername, filename)

            print(f"Scanning file: {file_path}")  # Progress output
            file_info = search_for_details_in_file(file_path)

            # Aggregate results
            for key in sensitive_info:
                sensitive_info[key].extend(file_info[key])

    return sensitive_info


def display_findings(sensitive_info):
    """
    Display all the findings in a user-friendly way.
    """
    if not sensitive_info:
        return "No sensitive information found."
    
    result = ""
    for info_type, data in sensitive_info.items():
        if data:
            result += f"\n--- {info_type} ---\n"
            for file_path, info in data:
                result += f"Found in {file_path}: {info}\n"
        else:
            result += f"\nNo {info_type} found.\n"
    
    return result


def main():
    # Get directory path from user
    directory_path = input("Enter the path to the directory where your bot files are located: ")

    # Strip quotes (if any) and validate the path
    directory_path = directory_path.strip('"')

    print(f"Scanning directory: {directory_path}")
    
    # Search the directory for sensitive information
    sensitive_info = search_directory_for_bot_details(directory_path)
    
    if sensitive_info is None:
        print("The provided directory path is invalid or empty.")
        return
    
    # Display the findings
    result = display_findings(sensitive_info)
    print(result)

    # Instructional Output
    print("\n--- Instructions for Inputting Values ---")
    print("Please enter the following details in the identified files:")
    print("1. **Bot API Token**: This is a long string consisting of numbers and letters (32 characters).")
    print("   - Find where it is stored and input your Bot Token there.")
    print("2. **Admin ID**: This is the Telegram User ID for the admin.")
    print("   - Look for the 'Admin ID' pattern and input the correct ID.")
    print("3. **API URL**: This URL is used for making requests to Telegram's Bot API (e.g., for setting webhooks).")
    print("   - Find the URL stored for API calls and ensure it's correct.")
    

if __name__ == "__main__":
    main()
