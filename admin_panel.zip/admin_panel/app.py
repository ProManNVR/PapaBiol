import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, send_from_directory
import sqlite3
from datetime import datetime, timedelta
import secrets

app = Flask(__name__)
app.secret_key = 'your-very-secret-key'  # Change this to a secure random key

# Hard-coded admin credentials (for demonstration only)
ADMIN_USERNAME = 'Unknown'
ADMIN_PASSWORD = 'Unknown@123RDP'  # In production, store securely!

DATABASE = os.path.join(os.getcwd(), 'licenses.db')

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize the database and create tables if they don't exist."""
    conn = get_db_connection()
    # Table for license keys
    conn.execute('''CREATE TABLE IF NOT EXISTS license_keys (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        key TEXT UNIQUE NOT NULL,
                        is_active INTEGER DEFAULT 1,
                        device_id TEXT,
                        expires_at TEXT,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP
                    )''')
    # Table for verification logs
    conn.execute('''CREATE TABLE IF NOT EXISTS verification_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        license_key TEXT,
                        device_id TEXT,
                        success INTEGER,
                        message TEXT,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP
                    )''')
    conn.commit()
    conn.close()

def generate_key():
    return secrets.token_urlsafe(32)

# ----------------------------
# Authentication & Session
# ----------------------------
def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            flash("Please login first", "warning")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Simple login form for the admin dashboard."""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['logged_in'] = True
            flash("Logged in successfully", "success")
            return redirect(url_for('admin_dashboard'))
        else:
            flash("Invalid credentials", "danger")
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    session.pop('logged_in', None)
    flash("Logged out successfully", "success")
    return redirect(url_for('login'))

# ----------------------------
# Admin Panel Routes
# ----------------------------
@app.route('/admin')
@login_required
def admin_dashboard():
    conn = get_db_connection()
    keys = conn.execute('SELECT * FROM license_keys').fetchall()
    conn.close()
    return render_template('dashboard.html', keys=keys)

@app.route('/admin/generate_key', methods=['POST'])
@login_required
def generate_license_key():
    try:
        valid_days = int(request.form.get('valid_days', 30))
    except ValueError:
        valid_days = 30
    expires_at = datetime.utcnow() + timedelta(days=valid_days)
    license_key = generate_key()
    
    conn = get_db_connection()
    conn.execute(
        'INSERT INTO license_keys (key, expires_at) VALUES (?, ?)',
        (license_key, expires_at.isoformat())
    )
    conn.commit()
    conn.close()
    
    flash(f'New license key generated: {license_key}', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/block_key/<string:key>')
@login_required
def block_license_key(key):
    conn = get_db_connection()
    conn.execute(
        'UPDATE license_keys SET is_active = 0 WHERE key = ?',
        (key,)
    )
    conn.commit()
    conn.close()
    
    flash(f'License key {key} blocked.', 'warning')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/unblock_key/<string:key>')
@login_required
def unblock_license_key(key):
    conn = get_db_connection()
    conn.execute(
        'UPDATE license_keys SET is_active = 1 WHERE key = ?',
        (key,)
    )
    conn.commit()
    conn.close()
    
    flash(f'License key {key} unblocked.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/logs')
@login_required
def view_logs():
    conn = get_db_connection()
    logs = conn.execute('SELECT * FROM verification_logs ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('logs.html', logs=logs)

# ----------------------------
# File Upload Endpoints (from user client)
# ----------------------------
@app.route('/upload_data', methods=['POST'])
def receive_upload():
    """
    Receives a ZIP file from the client.
    Expects a form field 'device_id' to identify the user.
    """
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part in request'}), 400

    file = request.files['file']
    device_id = request.form.get('device_id')
    if not device_id:
        return jsonify({'success': False, 'message': 'Missing device_id'}), 400

    if file.filename == '':
        return jsonify({'success': False, 'message': 'No file selected'}), 400

    # Create folder for this user if not exist
    upload_dir = os.path.join(os.getcwd(), 'uploads', device_id)
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)

    # Prefix filename with timestamp
    filename = f"{int(datetime.utcnow().timestamp())}_{file.filename}"
    file_path = os.path.join(upload_dir, filename)
    file.save(file_path)
    return jsonify({'success': True, 'message': 'File uploaded successfully'})


@app.route('/admin/uploads')
@login_required
def list_uploads():
    upload_dir = os.path.join(os.getcwd(), 'uploads')
    user_uploads = {}
    if os.path.exists(upload_dir):
        for user in os.listdir(upload_dir):
            user_path = os.path.join(upload_dir, user)
            if os.path.isdir(user_path):
                files = os.listdir(user_path)
                user_uploads[user] = files
    return render_template('uploads.html', user_uploads=user_uploads)


@app.route('/admin/download/<path:filename>')
@login_required
def download_file(filename):
    upload_dir = os.path.join(os.getcwd(), 'uploads')
    return send_from_directory(upload_dir, filename, as_attachment=True)

@app.route('/admin/delete/<path:filename>')
@login_required
def delete_file(filename):
    upload_dir = os.path.join(os.getcwd(), 'uploads')
    file_path = os.path.join(upload_dir, filename)
    if os.path.exists(file_path):
        try:
            os.remove(file_path)
            flash(f"File '{filename}' deleted successfully.", "success")
        except Exception as e:
            flash(f"Error deleting file '{filename}': {e}", "danger")
    else:
        flash(f"File '{filename}' does not exist.", "warning")
    return redirect(url_for('list_uploads'))

@app.template_filter('timestamp_to_date')
def timestamp_to_date_filter(ts):
    try:
        ts_int = int(ts)
        return datetime.utcfromtimestamp(ts_int).strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return ts


# ----------------------------
# API Endpoint for Key Verification (User Client Use)
# ----------------------------
@app.route('/verify_key', methods=['POST'])
def verify_key():
    data = request.get_json()
    license_key = data.get('license_key')
    device_id = data.get('device_id')
    
    if not license_key or not device_id:
        log_verification(license_key, device_id, False, 'Missing parameters')
        return jsonify({'success': False, 'message': 'Missing parameters'}), 400

    conn = get_db_connection()
    cur = conn.execute(
        'SELECT * FROM license_keys WHERE key = ?',
        (license_key,)
    )
    key_data = cur.fetchone()

    if key_data is None:
        conn.close()
        log_verification(license_key, device_id, False, 'Key does not exist')
        return jsonify({'success': False, 'message': 'Key does not exist'}), 400

    if not key_data['is_active']:
        conn.close()
        log_verification(license_key, device_id, False, 'Key is blocked')
        return jsonify({'success': False, 'message': 'Key is blocked'}), 400

    if key_data['expires_at']:
        expires_at = datetime.fromisoformat(key_data['expires_at'])
        if datetime.utcnow() > expires_at:
            conn.close()
            log_verification(license_key, device_id, False, 'Key expired')
            return jsonify({'success': False, 'message': 'Key expired'}), 400

    stored_device_id = key_data['device_id']
    if stored_device_id:
        if stored_device_id != device_id:
            conn.close()
            log_verification(license_key, device_id, False, 'Key already used on another device')
            return jsonify({'success': False, 'message': 'Key already used on another device'}), 400
    else:
        # Bind the key to the provided device_id
        conn.execute(
            'UPDATE license_keys SET device_id = ? WHERE key = ?',
            (device_id, license_key)
        )
        conn.commit()

    conn.close()
    log_verification(license_key, device_id, True, 'Key verified')
    return jsonify({'success': True, 'message': 'Key verified'})

def log_verification(license_key, device_id, success, message):
    """Log each license verification attempt."""
    conn = get_db_connection()
    conn.execute(
        'INSERT INTO verification_logs (license_key, device_id, success, message) VALUES (?, ?, ?, ?)',
        (license_key, device_id, 1 if success else 0, message)
    )
    conn.commit()
    conn.close()

# ----------------------------
# Main Entrypoint
# ----------------------------
if __name__ == '__main__':
    init_db()
    # Run the Flask app on port 9999 (accessible via your RDP IP:9999)
    app.run(host='0.0.0.0', port=9999, debug=True)
